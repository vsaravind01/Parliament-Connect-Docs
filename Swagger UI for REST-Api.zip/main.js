import express from "express";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
import Router from "./routes/index.js"; // Load routes
import db from "./models/admin.js"; // Load models
import swaggerUi from "swagger-ui-express";
import swaggerJsDoc from "swagger-jsdoc"; //swagger packages for documentation


const corsOptions = {
	origin: ["http://0.0.0.0:3000", "http://localhost:3000"],
	credentials: true, //access-control-allow-credentials:true
	optionSuccessStatus: 200,
};

dotenv.config(); // Load .env file

const swaggerOptions = {
	swaggerDefinition: {
		info: {
			title: 'Parliament-Connect API',
			description: "Get up-to-date parliament questions and their answers from the Parliament-Connect API. It provides seamless integration between both Rajya Sabha and Lokh Sabha. Members of Parliament can upload questions, the rescpective ministries can answer, and the general public can view them.",
			contact: {
				name: 'Data Bytes'
			},
			servers: ["http://localhost:5500"]
		}
	},
	apis: ['main.js', './routes/auth/authRouter.js', './routes/admin/adminRouter.js', './routes/features/featuresRouter.js', './routes/admin/adminRouterV2.js']
}; // Documentation Object

const app = express(); // Create express app
app.use(cors(corsOptions));

const swaggerDocs = swaggerJsDoc(swaggerOptions);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs)); // serving swagger

const port = process.env.PORT || 5500;

// Middleware utils
app.use(bodyParser.json());
app.use(cookieParser());

// Custom route middleware
/**
 * @swagger
 * /api:
 *  get:
 *    description: Auth api router
 *    tags:
 *     - Default
 */
app.use("/api", Router);

app.use((req, res) => {
	res.status(404).json({
		status: "error",
		message: `Invalid ${req.method} request to ${req.originalUrl}`,
	});
});

db.sync({ alter: true }) // Sync database - connect to postgresql
	.then(() => {
		// If success, start server
		app.listen(port, process.env.HOSTNAME, () => {
			console.log(
				"Server running on " + process.env.HOSTNAME + ":" + port
			);
		});
		console.log("Connection has been established successfully.");
	})
	.catch((err) => {
		// If error, log error
		console.error("Unable to connect to the database: " + err);
		if (err.parent.code === "3F000") {
			console.log("Schema does not exist.");
		}
	});
