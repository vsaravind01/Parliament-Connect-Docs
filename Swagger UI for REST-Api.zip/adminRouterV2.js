import adminRouterPath from "./admin.routes.js";
import verify from "../../middleware/auth.jwt.js";
import indexController from "../../controller/Indexer/index.controller.js";
import { Router } from "express";

const router = Router();

// POST /admin/parliament/sabha/create - create a new parliament (sabha) index
/**
 * @swagger
 * /api/admin/v2/parliament/index/create:
 *  post:
 *    description: Create a new parliament index
 *    tags:
 *      - Sabha
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Sabha
 *        schema:
 *          type: object
 *          properties:
 *            id:
 *             type: string
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(adminRouterPath.create_sabha, verify, indexController.create_index);
// POST /admin/parliament/sabha/delete - delete a parliament (sabha) index
/**
 * @swagger
 * /api/admin/v2/parliament/index/delete:
 *  post:
 *    description: Delete a parliament index
 *    tags:
 *      - Sabha
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Sabha
 *        schema:
 *          type: object
 *          properties:
 *            data:
 *             type: string
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request
 *      '201':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(adminRouterPath.delete_sabha, verify, indexController.delete_index);
// POST /admin/parliament/question/upload - upload a question to parliament (sabha) index
/**
 * @swagger
 * /api/admin/v2/parliament/question/upload:
 *  post:
 *    description: Upload a question
 *    tags:
 *      - Sabha
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Sabha
 *        schema:
 *          type: object
 *          properties:
 *            data:
 *             type: string
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request this
 *      '201':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(
	adminRouterPath.upload_question,
	verify,
	indexController.upload_question
);
// POST /admin/parliament/answer - upload an answer to parliament (sabha) index
/**
 * @swagger
 * /api/admin/v2/parliament/answer:
 *  post:
 *    description: Upload an answer
 *    tags:
 *      - Sabha
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Sabha
 *        schema:
 *          type: object
 *          properties:
 *            index:
 *             type: string
 *            id:
 *             type: string
 *            answer:
 *             type: string
 *            styled_answer:
 *             type: string
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request this
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(
	adminRouterPath.upload_answer,
	verify,
	indexController.upload_answer
);
// POST /admin/parliament/get/indices - get all parliament (sabha) indices
/**
 * @swagger
 * /api/admin/v2/parliament/get/indices:
 *  post:
 *    description: Get all indices
 *    tags:
 *      - Sabha
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Sabha
 *        schema:
 *          type: object
 *          properties:
 *            index:
 *             type: string
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request this
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(adminRouterPath.get_indices, verify, indexController.getIndices);
// POST /admin/parliament/mps - get all mp records
/**
 * @swagger
 * /api/admin/v2/parliament/mp:
 *  post:
 *    description: Get all MP records
 *    tags:
 *      - Sabha
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Sabha
 *        schema:
 *          type: object
 *          properties:
 *            data:
 *             type: string
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request this
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(adminRouterPath.get_mps, verify, indexController.getMPs);
// POST /admin/parliament/unanswered - get all unanswered questions
/**
 * @swagger
 * /api/admin/v2/parliament/unanswered:
 *  post:
 *    description: Get all unanswered questions
 *    tags:
 *      - Sabha
 *    
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request this
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(
	adminRouterPath.get_user_unanswered_questions,
	verify,
	indexController.getUserUnansweredQuestions
);

export default router;
