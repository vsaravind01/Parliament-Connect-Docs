import { Router } from "express";
import featuresRoutes from "./features.routes.js";
import pollsController from "../../controller/features/polls.controller.js";
import postsController from "../../controller/features/posts.controller.js";
import verify from "../../middleware/auth.jwt.js";

const router = Router();

// POST /features/polls - create a new poll
/**
 * @swagger
 * /api/admin/features/polls/create:
 *  post:
 *    description: Create a new poll
 *    tags:
 *      - Features
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Poll
 *        schema:
 *          type: object
 *          properties:
 *            question:
 *              type: string
 *            description:
 *              type: string
 *            expiryDate:
 *              type: string
 *            expiryTime:
 *              type: string
 *            optionsArray:
 *              type: array
 *              items:
 *                ref: '#/definitions/mpObject'
 *  
 *    responses:
 *      '200':
 *         description: Success
 *      '403':
 *        description: Unauthorized
 *      '400':
 *        description: Bad request
 *      '500':
 *        description: Internal server error
 * 
 *  definitions:
 *    mpObject:
 *      type: object
 *      properties:
 *       name:
 *         type: string
 *         description: Options
 */
router.post(featuresRoutes.polls_create, verify, pollsController.createPoll);
// POST /features/polls/delete - delete a poll
/**
 * @swagger
 * /api/admin/features/polls/delete:
 *  post:
 *    description: Delete a poll
 *    tags:
 *      - Features
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Poll
 *        schema:
 *          type: object
 *          properties:
 *            id:
 *              type: string
 *    responses:
 *      '400':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(featuresRoutes.polls_delete, verify, pollsController.deletePoll);
// POST /features/polls/get/all - get all polls
/**
 * @swagger
 * /api/admin/features/polls/get/all:
 *  post:
 *    description: Get all polls
 *    tags:
 *      - Features
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Poll
 *        schema:
 *          type: object
 *          required: False
 *          properties:
 *            page:
 *              type: string
 *            limit:
 *              type: string
 *    responses:
 *      '400':
 *        description: Bad request
 *      '404':
 *        description: Not Found
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(
	featuresRoutes.polls_get_all,
	verify,
	pollsController.getAllUserPolls
);
// POST /features/polls/update - update a poll
/**
 * @swagger
 * /api/admin/features/polls/update:
 *  post:
 *    description: Update a poll
 *    tags:
 *      - Features
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Poll
 *        schema:
 *          type: object
 *          properties:
 *            question:
 *              type: string
 *            description:
 *              type: string
 *            expiryDate:
 *              type: string
 *            expiryTime:
 *              type: string
 *            optionsArray:
 *              type: array
 *              items:
 *                ref: '#/definitions/mpObject'
 *    responses:
 *      '400':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
 *  definitions:
 *    mpObject:
 *      type: object
 *      properties:
 *       name:
 *         type: string
 *         description: Options
*/
router.post(featuresRoutes.polls_update, verify, pollsController.updatePoll);
// POST /features/polls/get - get a poll
/**
 * @swagger
 * /api/admin/features/polls/get/{Poll}:
 *  get:
 *    description: Get a poll
 *    tags:
 *      - Features
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: path
 *        name: Poll
 *        schema:
 *          type: object
 *          required: True
 *          properties:
 *            id:
 *              type: string
 *    responses:
 *      '400':
 *        description: Bad request
 *      '404':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.get(featuresRoutes.polls_get, verify, pollsController.getPoll);
// POST /features/polls/vote - vote on a poll
/**
 * @swagger
 * /api/admin/features/polls/vote:
 *  post:
 *    description: Get a polls
 *    tags:
 *      - Features
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: path
 *        name: Poll
 *        schema:
 *          type: object
 *          required: True
 *          properties:
 *            id:
 *              type: string
 *            optionKey:
 *              type: string
 *    responses:
 *      '400':
 *        description: Bad request
 *      '404':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(featuresRoutes.polls_vote, verify, pollsController.vote);

// Posts

// POST /features/posts/create - create a new post
/**
 * @swagger
 * /api/admin/features/posts/create:
 *  post:
 *    description: Create a new post
 *    tags:
 *      - Features-Posts
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Post
 *        schema:
 *          type: object
 *          required: True
 *          properties:
 *            title:
 *              type: string
 *            image:
 *              type: string
 *            content:
 *              type: string
 *            tags:
 *               type: string
 *    responses:
 *      '400':
 *        description: Bad request
 *      '403':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(featuresRoutes.posts_create, verify, postsController.createPost);
// POST /features/posts/get/all - get all posts
/**
 * @swagger
 * /api/admin/features/posts/all:
 *  post:
 *    description: Get all posts
 *    tags:
 *      - Features-Posts
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Post
 *        schema:
 *          type: object
 *          required: False
 *          properties:
 *            page:
 *              type: string
 *            limit:
 *              type: string
 *    responses:
 *      '400':
 *        description: Bad request
 *      '403':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.post(
	featuresRoutes.posts_get_all_by_user,
	verify,
	postsController.getAllUserPosts
);
// POST /features/posts/get - get a post
/**
 * @swagger
 * /api/admin/features/posts/get/{Post}:
 *  get:
 *    description: Get a post
 *    tags:
 *      - Features-Posts
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: path
 *        name: Post
 *        schema:
 *          type: object
 *          properties:
 *            id:
 *             type: string     
 *    responses:
 *      '201':
 *        description: Success
 *      '400':
 *        description: Bad request
 *      '500':
 *        description: Internal Server Error
*/
router.get(featuresRoutes.posts_get, verify, postsController.getPost);
// POST /features/posts/update - update a post
/**
 * @swagger
 * /api/admin/features/posts/update:
 *  post:
 *    description: Update a post
 *    tags:
 *      - Features-Posts
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Post
 *        schema:
 *          type: object
 *          properties:
 *            id:
 *             type: string
 *            title:
 *              type: string
 *            image:
 *               type: string
 *            content:
 *                type: string
 *            tags:
 *                type: string   
 *    responses:
 *      '201':
 *        description: Success
 *      '400':
 *        description: Bad request
 *      '500':
 *        description: Internal Server Error
 *      '403':
 *        description: Bad request
*/
router.post(featuresRoutes.posts_update, verify, postsController.updatePost);
// POST /features/posts/delete - delete a post
/**
 * @swagger
 * /api/admin/features/posts/delete:
 *  post:
 *    description: Delete a post
 *    tags:
 *      - Features-Posts
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Post
 *        schema:
 *          type: object
 *          properties:
 *            id:
 *             type: string     
 *    responses:
 *      '201':
 *        description: Success
 *      '404':
 *        description: Bad request
 *      '500':
 *        description: Internal Server Error
 *      '403':
 *        description: Bad request
*/
router.post(featuresRoutes.posts_delete, verify, postsController.deletePost);
// POST /features/posts/like - like a post
/**
 * @swagger
 * /api/admin/features/posts/like:
 *  post:
 *    description: Like a post
 *    tags:
 *      - Features-Posts
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Post
 *        schema:
 *          type: object
 *          properties:
 *            id:
 *             type: string     
 *    responses:
 *      '201':
 *        description: Success
 *      '404':
 *        description: Bad request
 *      '500':
 *        description: Internal Server Error
 *      '403':
 *        description: Bad request
*/
router.post(featuresRoutes.like_post, verify, postsController.likePost);
// POST /features/posts/unlike - unlike a post
/**
 * @swagger
 * /api/admin/features/posts/unlike:
 *  post:
 *    description: Unlike a post
 *    tags:
 *      - Features-Posts
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Post
 *        schema:
 *          type: object
 *          properties:
 *            id:
 *             type: string     
 *    responses:
 *      '201':
 *        description: Success
 *      '404':
 *        description: Bad request
 *      '500':
 *        description: Internal Server Error
 *      '403':
 *        description: Bad request
 *      '400':
 *        description: Bad request
*/
router.post(featuresRoutes.unlike_post, verify, postsController.unlikePost);
// router.post(featuresRoutes.posts_get_all, verify, postsController.getPosts);
export default router;
