import { Router } from "express";
import authRouterPath from "./auth.routes.js";
import auth from "../../controller/auth/auth.controller.js";
import verifyToken from "../../middleware/auth.jwt.js";
const router = Router();
// direct_admin auth routes

// POST /auth/signup - create a new admin user
/**
 * @swagger
 * /api/auth/signup:
 *  post:
 *    description: Creates new admin user 
 *    tags:
 *      - Auth
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: user
 *        schema:
 *          type: object
 *          required:
 *            - uname
 *            - password
 *          properties:
 *            uname:
 *              type: string
 *            password:
 *              type: string
 *            role:
 *              type: string
 *              enum:
 *                - admin
 *                - MP
 *                - Ministry
 *              example: admin
 *            ref_id:
 *              type: string
 *              example: 7987
 *    responses:
 *      '201':
 *        description: Success
 *      '400':
 *        description: Bad request
 *      '500':
 *        description: Internal Server Error
*/
router.post(authRouterPath.admin_signup, auth.admin_signup);
// POST /auth/login - login an admin user
/**
 * @swagger
 * /api/auth/login:
 *  post:
 *    description: Logs in an admin user
 *    tags:
 *      - Auth
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: user
 *        schema:
 *          type: object
 *          properties:
 *            uname:
 *              type: string
 *            password:
 *              type: string
 *            role:
 *              type: string
 * 
 *    responses:
 *      '200':
 *        description: Success
 *      '400':
 *        description: Password Incorrect/ Missing Required Fields
 *      '500':
 *        description: Internal Server Error
*/
router.post(authRouterPath.admin_login, auth.admin_login);
// POST /auth/logout - logout an admin user
/**
 * @swagger
 * /api/auth/logout:
 *  post:
 *    description: Logouts an admin user
 *    tags:
 *      - Auth
 *    responses:
 *      '200':
 *        description: Success
 *      '404':
 *        description: Bad Request
 *      '500':
 *        description: Internal Server Error
*/
router.post(authRouterPath.admin_logout, auth.admin_logout);
// POST /auth/authorize - authorize an admin user
/**
 * @swagger
 * /api/auth/authorize:
 *  get:
 *    description: Authorizes an admin user
 *    tags:
 *      - Auth
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: user
 *        schema:
 *          type: object
 *          properties:
 *            uname:
 *              type: string
 *            password:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '401':
 *        description: Bad Request
 *      '500':
 *        description: Internal Server Error
*/
router.get(authRouterPath.admin_authorize, auth.admin_authorize);
// POST /auth/change_password - change admin user password
/**
 * @swagger
 * /api/auth/change_password:
 *  get:
 *    description: Auth change password
 *    tags:
 *      - Auth
 *    consumes: 
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: user
 *        schema:
 *          type: object
 *          properties:
 *            uname:
 *              type: string
 *            password:
 *              type: string
 *            newPassword:
 *              type: string
 *    responses:
 *      '404':
 *        description: Bad request
 *      '400':
 *        description: Bad request
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal server error
*/
router.get(authRouterPath.change_password, verifyToken, auth.change_password)
export default router;