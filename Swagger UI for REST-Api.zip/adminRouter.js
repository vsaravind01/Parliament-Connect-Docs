import { Router } from "express";
import adminRouterPath from "./admin.routes.js";
import admin from "../../controller/parliament/parliament.controller.js";
import mpController from "../../controller/parliament/mp.controller.js";
import ministryController from "../../controller/parliament/ministry.controller.js";
import indexController from "../../controller/Indexer/index.controller.js";
import verify from "../../middleware/auth.jwt.js";

const router = Router();

// ADMIN CONTROLLER

// POST /admin/parliament/sabha/create - create a new parliament (partition)
/**
 * @swagger
 * /api/admin/parliament/sabha/create:
 *  post:
 *    description: Create a new parliament
 *    tags:
 *      - ADMIN CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: admin
 *        schema:
 *          type: object
 *          properties:
 *            sabha:
 *              type: string
 *            version:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
*/
router.post(adminRouterPath.create_parliament, verify, admin.createParliament);
// PUT /admin/parliament/sabha/set_version - update the current parliament (sabha) version
/**
 * @swagger
 * /api/admin/parliament/sabha/set_version:
 *  put:
 *    description: Update the current parliament
 *    tags:
 *      - ADMIN CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: admin
 *        schema:
 *          type: object
 *          properties:
 *            sabha:
 *              type: string
 *            version:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
*/
router.put(
	adminRouterPath.set_parliament_version,
	verify,
	admin.setCurrentParliamentVersion
);
// DELETE /admin/parliament/sabha/delete - delete a parliament (sabha)
/**
 * @swagger
 * /api/admin/parliament/sabha/delete:
 *  delete:
 *    description: Delete a parliament
 *    tags:
 *      - ADMIN CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: admin
 *        schema:
 *          type: object
 *          properties:
 *            sabha:
 *              type: string
 *            version:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
*/
router.delete(
	adminRouterPath.delete_parliament,
	verify,
	admin.deleteParliament
);

// GET /admin/parliament/sabha/get_version - fetch the current parliament (sabha) version
/**
 * @swagger
 * /api/admin/parliament/sabha/get_version:
 *  get:
 *    description: Fetches the current parliament
 *    tags:
 *      - ADMIN CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: admin
 *        schema:
 *          type: object
 *          properties:
 *            sabha:
 *              type: string
 *            version:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
*/
router.get(
	adminRouterPath.get_parliament_version,
	verify,
	admin.getCurrentParliamentVersion
);

// MP CONTROLLER
// GET /admin/parliament/mp/id - get mp details by id
/**
 * @swagger
 * /api/admin/parliament/mp/id/{MP}:
 *  get:
 *    description: Get MP details by ID
 *    tags:
 *      - MP CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: path
 *        name: MP
 *        schema:
 *          type: object
 *          properties:
 *            mp_id:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
*/
router.get(adminRouterPath.getMpById, verify, mpController.getMpById);
// GET /admin/parliament/mp/all - get all mps
/**
 * @swagger
 * /api/admin/parliament/mp/all:
 *  get:
 *    description: Get all MPs
 *    tags:
 *      - MP CONTROLLER
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '401':
 *        description: Unauthorized
*/
router.get(adminRouterPath.getAllMps, verify, mpController.getAllMps);
// POST /admin/parliament/mp/register - register a new MP
/**
 * @swagger
 * /api/admin/parliament/mp/register:
 *  post:
 *    description: Register a new MP
 *    tags:
 *      - MP CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: MP
 *        schema:
 *          type: object
 *          properties:
 *            mp_id:
 *              type: string
 *            name:
 *              type: string
 *            ismp :
 *              type: string
 *            party_name :
 *              type: string
 *            sabha :
 *              type: string
 *            sabha_version :
 *              type: string
 *            constituency :
 *              type: string
 *            created_at :
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '400' :
 *        description: Bad Request
*/
router.post(adminRouterPath.register_mp, verify, mpController.registerMp);
// POST /admin/parliament/mp/all/name - get all mp names
/**
 * @swagger
 * /api/admin/parliament/mp/all/name:
 *  get:
 *    description: Get all MP names
 *    tags:
 *      - MP CONTROLLER
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '401':
 *        description: Unauthorized
*/
router.get(adminRouterPath.getAllMpNames, mpController.getAllMpNames);
// DELETE /admin/parliament/mp/delete - delete a MP
/**
 * @swagger
 * /api/admin/parliament/mp/id:
 *  delete:
 *    description: Delete a MP
 *    tags:
 *      - MP CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: MP
 *        schema:
 *          type: object
 *          properties:
 *            mp_id:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '400' :
 *        description: Bad Request
*/
router.delete(adminRouterPath.deleteMpById, verify, mpController.deleteMp);
// MINISTRY CONTROLLER
// POST /admin/parliament/ministry/register - register a new ministry
/**
 * @swagger
 * /api/admin/parliament/ministry/register:
 *  post:
 *    description: Register a new ministry
 *    tags:
 *      - Ministry CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Ministry
 *        schema:
 *          type: object
 *          properties:
 *            name:
 *              type: string
 *            minister:
 *              type: string
 *            group:
 *              type: string
 *            mp_ref:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '400' :
 *        description: Bad Request
*/
router.post(
	adminRouterPath.register_ministry,
	verify,
	ministryController.registerMinistry
);
// GET /admin/parliament/ministry/id - get ministry details by id
/**
 * @swagger
 * /api/admin/parliament/ministry/id:
 *  get:
 *    description: Get ministry details
 *    tags:
 *      - Ministry CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: Ministry
 *        schema:
 *          type: object
 *          properties:
 *            mid:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '400' :
 *        description: Bad Request
*/
router.get(
	adminRouterPath.getMinistryById,
	verify,
	ministryController.getMinistryById
);
// GET /admin/parliament/ministry/all - get all ministries
/**
 * @swagger
 * /api/admin/parliament/ministry/all:
 *  get:
 *    description: Get all ministries
 *    tags:
 *      - Ministry CONTROLLER
 *    consumes:
 *      - application/json
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '400' :
 *        description: Bad Request
*/
router.get(
	adminRouterPath.getAllMinistries,
	verify,
	ministryController.getAllMinistries
);
// GET /admin/parliament/ministry/all/name - get all ministry names
/**
 * @swagger
 * /api/admin/parliament/ministry/all/name:
 *  get:
 *    description: Get all ministry names
 *    tags:
 *      - Ministry CONTROLLER
 *    consumes:
 *      - application/json
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '400' :
 *        description: Bad Request
*/
router.get(
	adminRouterPath.getAllMinistryNames,
	ministryController.getAllMinistryNames
);
// DELETE /admin/parliament/ministry/delete - delete a ministry
/**
 * @swagger
 * /api/admin/parliament/ministry/id:
 *  delete:
 *    description: Delete a ministry
 *    tags:
 *      - Ministry CONTROLLER
 *    consumes:
 *      - application/json
 *    parameters:
 *      - in: body
 *        name: MP
 *        schema:
 *          type: object
 *          properties:
 *            mid:
 *              type: string
 *    responses:
 *      '200':
 *        description: Success
 *      '500':
 *        description: Internal Server Error
 *      '400' :
 *        description: Bad Request
*/
router.delete(
	adminRouterPath.deleteMinistryById,
	verify,
	ministryController.deleteMinistry
);

export default router;
